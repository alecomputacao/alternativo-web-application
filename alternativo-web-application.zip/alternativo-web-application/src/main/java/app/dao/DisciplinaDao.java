package app.dao;

import app.model.Disciplina;

public class DisciplinaDao extends DaoImpl<Disciplina> {

	public DisciplinaDao(Class<Disciplina> clazz) {
		super(clazz);
	}

}
