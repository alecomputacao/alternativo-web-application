package app.dao;

import app.model.Endereco;

public class EnderecoDao extends DaoImpl<Endereco> {

	public EnderecoDao(Class<Endereco> clazz) {
		super(clazz);
	}

}
