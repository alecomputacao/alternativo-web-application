package app.dao;

import app.model.Evento;

public class EventoDao extends DaoImpl<Evento> {

	public EventoDao(Class<Evento> clazz) {
		super(clazz);
	}

}
