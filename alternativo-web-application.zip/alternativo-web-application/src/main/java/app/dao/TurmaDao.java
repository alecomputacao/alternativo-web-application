package app.dao;

import app.model.Turma;

public class TurmaDao extends DaoImpl<Turma> {

	public TurmaDao(Class<Turma> clazz) {
		super(clazz);
	}

}
