package app.util;

public enum Status {
	ATIVO, INATIVO;
}
