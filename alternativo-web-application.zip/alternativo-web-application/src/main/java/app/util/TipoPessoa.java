package app.util;

public enum TipoPessoa {
	ALUNO, PROFESSOR;
}
