package app.util;

public enum TipoDocumento {
	CPF, RG, CNPJ, PASSAPORTE, INTERNACIONAL, OUTRO;
}
